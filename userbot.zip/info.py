import os

"""
os.environ["number"] = "+5511950891476" #"+5584996412880" 
os.environ["api_hash"] = "60914433b8f4fde57c6ba475f572f912"
os.environ["api_id"] = "28357147"

os.environ["host"] = 'uyu7j8yohcwo35j3.cbetxkdyhwsb.us-east-1.rds.amazonaws.com'
os.environ["user"] = 'h2xwhmugacxbwv79'
os.environ["password"] ='mfuwh70z5pjq0jwb'
os.environ["database"] = 'q6p5up8xhrrbmyq0'
"""

#Bot information
API_HASH = os.environ['api_hash']
API_ID = os.environ['api_id']
NUMBER = os.environ['number']
SESSION = os.environ['session']

#SQL information
HOST = os.environ['host']
USER = os.environ['user']
PASSWORD=os.environ['password']
DATABASE = os.environ['database']

def define_grupo():
	if TITULAR != 886429586:
		LOBINDIE = -1001366864342
		STAFF = -1001572420135
	else:
		LOBINDIE = -1001217627450
		STAFF = -1001217627450
	return LOBINDIE, STAFF
		
#Admins, Channels & Users
LOGS= -1001865449571
TITULAR = 886429586 #mudar
AUTORIZADOS = [836445988, 934735022, 934923747, 886429586]
LOBINDIEFIXO= -1001366864342
LOBINDIE, _ = define_grupo()#mudar
TESTES = -1001217627450
INDIEMUSIC = "-1001302341410"
_, STAFF = define_grupo() #mudar
RANKING = -423539628
IMAGENS = -1001984560446

