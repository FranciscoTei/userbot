import os

#Bot information
API_HASH = os.environ['api_hash']
API_ID = os.environ['api_id']
SESSION = os.environ['session']

#SQL information
HOST = os.environ['host']
USER = os.environ['user']
PASSWORD=os.environ['password']
DATABASE = os.environ['database']

#Admins, Channels & Users
LOGS= -1001964074508
TITULAR = 886429586
AUTORIZADOS = [836445988, 934735022, 934923747, 886429586]
LOBINDIEFIXO= -1001366864342
LOBINDIE = -1001366864342 #mudar
TESTES = -1001217627450
STAFF = -1001572420135 #mudar
RANKING = -423539628